#!/bin/sh
echo "ProcessID=$$ begins ($0)"
echo "$$" >> pid
sleep 9999
echo "ProcessID=$$ ends ($0)"